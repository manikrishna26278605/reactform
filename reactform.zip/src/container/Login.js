import React, { Component } from 'react';
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux';
import {loginAction} from '../actions';


class Login extends Component {
    constructor(){
        super();
        this.state = {  }
    }


    componentDidMount(){
        // this.props.dispatch(
            this.props.loginAction()
            //);
        // dispatch 
    }
    
    render() { 
        return ( 
                <div> 
                   Login 
                </div> 
             );
    }

}

function mapStateToProps(state) {
    return { state }
  }

  function mapDispatchToProps(dispatch) {
    // return bindActionCreators(
    //     {loginAction }, // do not include dispatch here
    //     dispatch
    //   );
    return {
        loginAction: ()=> dispatch(loginAction())
        } 
  }

 
export default connect( mapStateToProps, mapDispatchToProps )(Login);
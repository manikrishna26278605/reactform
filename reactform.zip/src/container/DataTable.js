import React, { Component } from 'react';

class DataTable extends Component {
    constructor(){
        super();
        this.state = {  }
    }
    
    render() { 
        return ( 
                <div> 
                   DataTable 
                </div> 
             );
    }

}
 
export default DataTable;
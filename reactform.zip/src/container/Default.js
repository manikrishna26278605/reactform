import React, { Component } from 'react';

class Default extends Component {
    constructor(){
        super();
        this.state = {  }
    }
    
    render() { 
        return ( 
                <div> 
                    404 - page not found
                </div> 
             );
    }

}
 
export default Default;